"use strict";
/**
 * Cognito PostConfirmation Lambda Trigger
 *
 * Automatically creates user records in PostgreSQL when a user
 * confirms their account in Cognito.
 *
 * This Lambda is triggered after:
 * - Email verification
 * - Phone verification
 * - Admin confirmation
 *
 * Requirements: 2.1
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const pg_1 = require("pg");
/**
 * Database connection pool
 * Reused across Lambda invocations for better performance
 */
let pool = null;
/**
 * Get or create database connection pool
 */
function getPool() {
    if (!pool) {
        pool = new pg_1.Pool({
            host: process.env.DB_HOST,
            port: parseInt(process.env.DB_PORT || '5432'),
            database: process.env.DB_NAME,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            max: 5, // Limit connections in Lambda
            idleTimeoutMillis: 30000,
            connectionTimeoutMillis: 5000,
        });
    }
    return pool;
}
/**
 * PostConfirmation Lambda Handler
 *
 * Creates user and user_profile records in PostgreSQL when a user
 * confirms their Cognito account.
 *
 * @param event - Cognito PostConfirmation trigger event
 * @param context - Lambda context
 * @returns Modified event (required by Cognito)
 */
const handler = async (event, context) => {
    console.log('PostConfirmation trigger event:', JSON.stringify(event, null, 2));
    const { userPoolId, userName, request } = event;
    const { userAttributes } = request;
    // Extract user information from Cognito event
    const userId = userAttributes.sub;
    const email = userAttributes.email;
    const nickname = userAttributes.preferred_username || userAttributes.email.split('@')[0];
    console.log(`Creating user record for: ${email} (${userId})`);
    const db = getPool();
    const client = await db.connect();
    try {
        // Start transaction
        await client.query('BEGIN');
        // Insert user record
        const userQuery = `
      INSERT INTO users (user_id, email, nickname, status, created_at, updated_at)
      VALUES ($1, $2, $3, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      ON CONFLICT (user_id) DO UPDATE
      SET email = EXCLUDED.email,
          nickname = EXCLUDED.nickname,
          updated_at = CURRENT_TIMESTAMP
      RETURNING user_id
    `;
        const userResult = await client.query(userQuery, [userId, email, nickname]);
        console.log(`User record created/updated: ${userResult.rows[0].user_id}`);
        // Insert empty user_profile record
        const profileQuery = `
      INSERT INTO user_profiles (user_id, created_at, updated_at)
      VALUES ($1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      ON CONFLICT (user_id) DO NOTHING
      RETURNING profile_id
    `;
        const profileResult = await client.query(profileQuery, [userId]);
        if (profileResult.rows.length > 0) {
            console.log(`User profile created: ${profileResult.rows[0].profile_id}`);
        }
        else {
            console.log('User profile already exists');
        }
        // Commit transaction
        await client.query('COMMIT');
        console.log('User synchronization successful');
        return event;
    }
    catch (error) {
        // Rollback transaction on error
        await client.query('ROLLBACK');
        console.error('Error synchronizing user to database:', error);
        // Log error but don't fail the Cognito operation
        // Database sync can be fixed manually later
        console.error('User created in Cognito but database sync failed for user:', userId);
        console.error('Manual intervention may be required');
        // Return event to allow Cognito signup to succeed
        return event;
    }
    finally {
        // Release client back to pool
        client.release();
    }
};
exports.handler = handler;
/**
 * Cleanup function (called when Lambda container is terminated)
 */
process.on('beforeExit', async () => {
    if (pool) {
        await pool.end();
        pool = null;
    }
});
//# sourceMappingURL=postConfirmation.js.map