"use strict";
/**
 * Cognito PostAuthentication Lambda Trigger
 *
 * Updates the last_login timestamp in PostgreSQL when a user
 * successfully authenticates with Cognito.
 *
 * This Lambda is triggered after:
 * - Successful password authentication
 * - Successful OAuth authentication (Google, etc.)
 * - Successful refresh token authentication
 *
 * Requirements: 2.2
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const pg_1 = require("pg");
/**
 * Database connection pool
 * Reused across Lambda invocations for better performance
 */
let pool = null;
/**
 * Get or create database connection pool
 */
function getPool() {
    if (!pool) {
        pool = new pg_1.Pool({
            host: process.env.DB_HOST,
            port: parseInt(process.env.DB_PORT || '5432'),
            database: process.env.DB_NAME,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            max: 5, // Limit connections in Lambda
            idleTimeoutMillis: 30000,
            connectionTimeoutMillis: 5000,
        });
    }
    return pool;
}
/**
 * PostAuthentication Lambda Handler
 *
 * Updates the last_login timestamp in PostgreSQL when a user
 * successfully authenticates.
 *
 * @param event - Cognito PostAuthentication trigger event
 * @param context - Lambda context
 * @returns Modified event (required by Cognito)
 */
const handler = async (event, context) => {
    console.log('PostAuthentication trigger event:', JSON.stringify(event, null, 2));
    const { userPoolId, userName, request } = event;
    const { userAttributes } = request;
    // Extract user ID from Cognito event
    const userId = userAttributes.sub;
    console.log(`Updating last_login for user: ${userId}`);
    const db = getPool();
    try {
        // Update last_login timestamp
        const query = `
      UPDATE users
      SET last_login = CURRENT_TIMESTAMP
      WHERE user_id = $1
      RETURNING user_id, last_login
    `;
        const result = await db.query(query, [userId]);
        if (result.rows.length > 0) {
            console.log(`Last login updated: ${result.rows[0].last_login}`);
        }
        else {
            console.warn(`User not found in database: ${userId}`);
            // User might not be synced yet, but don't fail authentication
        }
        return event;
    }
    catch (error) {
        console.error('Error updating last_login:', error);
        // Don't fail authentication even if database update fails
        // This is a non-critical operation
        return event;
    }
};
exports.handler = handler;
/**
 * Cleanup function (called when Lambda container is terminated)
 */
process.on('beforeExit', async () => {
    if (pool) {
        await pool.end();
        pool = null;
    }
});
//# sourceMappingURL=postAuthentication.js.map